# Version: 1.0
# Date: 09 september 2004
# Description: Program to translate Citrix Keyboard scan codes to output replay of keyboard strokes
# The original WFCWIN32.LOG file can be used as a parameter of this perl script
# Credits: Andre van der Lingen - System Engineer Interpay Nederland B.V.
# Robert-Jan Mora - Forensic Investigator Hoffmann Investigations
# Best performance in Perl 5.6.1 due to Time::HiRes module issues in 5.8
# Modules
use Time::HiRes qw(usleep);
####################################### Main
################################
# Read Associative Array
&read_array;
$FILE = @ARGV[0];
if (@ARGV[0] eq "") {
print "Give log file as parameter"
}
# Open the Citrix log file from the parameter
&open_file;
# Process and translate the log file
foreach $scancode (@ALL) {
chomp $scancode;
$scancode=~s/^.*\(//;
$scancode=~s/\)//;
#print $scancode;
if ($scancode eq "36" or $scancode eq "2A") {
$shift_key = 1;
next;
} else {
&print_ouput;
}
}
####################################### Subs
################################
#Not scanning for release scancodes.
sub print_ouput {
usleep 100000;
$table_value = "$table{\"$scancode\"}";
if ($shift_key) {
$table_value =~ s/^.//;
} else {
$table_value =~ s/.$//;
}
print ("$table_value");
$shift_key = 0;
}
sub open_file {
if ( -e $FILE) {
open (F, $FILE) || die "Could not find file name $FILE" ;
@ALL = <F> ;
#print "\n@ALL\n\n" unless ($NODEBUG) ;
close F ;
}

}
sub read_array {
%table = ("1E","aA",
"30","bB",
"2E","cC",
"20","dD",
"12","eE",
"21","fF",
"22","gG",
"23","hH",
"17","iI",
"24","jJ",
"25","kK",
"26","lL",
"32","mM",
"31","nN",
"18","oO",
"19","pP",
"10","qQ",
"13","rR",
"1F","sS",
"14","tT",
"16","uU",
"2F","vV",
"11","wW",
"2D","xX",
"15","yY",
"2C","zZ",
"02","1!",
"03","2@",
"04","3#",
"05","4\$",
"06","5%",
"07","6^",
"08","7&",
"09","8*",
"0A","9(",
"0B","0)",
"39"," ", #Two spaces
"1C","\n\n",
"0F","\t\t",
"0E","\b\b",
"0C","-_",
"0D","=+",
"1A","\[\{",
"1B","\]\}",
"2B","\\|",
"27",";:",
"28","\'\"",
"29","\`~",
"33",",<",
"34",".>",
"35","\/?",
"36"," -RightShift- ",
"2A"," -LeftShift- ");
}