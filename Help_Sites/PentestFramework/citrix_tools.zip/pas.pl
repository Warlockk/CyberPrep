#!/usr/bin/perl
$|=1;
open(INDATA, "pas.wri") or die "Cant read data file: $!\n";
open(RESULT, ">pas_results.wri") or die "Cant create result file: $!\n";
while($line=<INDATA>) {
  chomp $line;
  next if( $line!~/^(\d+\.\d+\.\d+\.\d+)\|\d+\.\d+\.\d+\.\d+\|[01]\|(.+)/ );
  $ip=$1;
  @pa=split(';',$2);
  foreach $test_pa (@pa) {
    open(TEMPLATE,"template.ica") or die "Cant open template file: $!\n";
    open(ICA,">ica.ica") or die "Cant create ica file; $!\n";
    while($tline=<TEMPLATE>) {
      $tline=~s/IPIPIP/$ip/;
      $tline=~s/PAPAPA/$test_pa/;
      print ICA $tline;
    }
    close(ICA);
    system('ica.ica');
    $result=0;
    while($result < 1 || $result > 5) {
      print "\nHow did the connect to $test_pa on $ip go?\n";
      print "1: Wery well, anonymous login, but no desktop.\n";
      print "2: Anonymous and vulnerable.\n";
      print "3: Login required.\n";
      print "4: Error. No connection or similar.\n";
      print "\n";
      print "5: Redo\n";
      print "> ";
      $result=<>;
      chomp $result;
    }
    redo if($result==5);
    print RESULT "$ip\|$test_pa|$result\n";
    
  }
}
